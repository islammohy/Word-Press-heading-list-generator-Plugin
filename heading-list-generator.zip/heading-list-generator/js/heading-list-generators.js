document.addEventListener('DOMContentLoaded', function() {
    // Check if the headingsData object exists
    if (typeof headingsData === 'undefined') {
        // headingsData is not defined, initialize with empty values
        headingsData = {
            siteTitle: "",
            postTitle: ""
        };
    } else {
        // Check if siteTitle and postTitle are defined, otherwise set them to empty strings
        headingsData.siteTitle = headingsData.siteTitle || "";
        headingsData.postTitle = headingsData.postTitle || "";
    }

    // Check if the headingListContainer exists
    const headingListContainer = document.getElementById('gheadinglistid');
    if (!headingListContainer) {
        return; // Skip list generation if the container element is not found
    }

    const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    const headingList = document.createElement('ul');
    const stack = [{ level: 0, parent: headingList }];

    headings.forEach((heading, index) => {
        // Check if the current heading matches the site title or post/page title
        const headingText = heading.textContent.trim().toLowerCase();
        const siteTitle = headingsData.siteTitle.trim().toLowerCase();
        const postTitle = headingsData.postTitle.trim().toLowerCase();
        const isFirstElement = index === 0 && headingText === siteTitle;
        const isSecondElement = index === 1 && headingText === postTitle;
        if (!isFirstElement && !isSecondElement) {
            const listItem = document.createElement('li');
            const link = document.createElement('a');
            link.textContent = heading.textContent;
            link.href = `#heading${index + 1}`;
            listItem.appendChild(link);

            const currentLevel = parseInt(heading.tagName.charAt(1));

            while (currentLevel <= stack[stack.length - 1].level) {
                stack.pop();
            }

            if (currentLevel > stack[stack.length - 1].level) {
                const subList = document.createElement('ul');
                stack[stack.length - 1].parent.appendChild(subList);
                stack.push({ level: currentLevel, parent: subList });
            }

            stack[stack.length - 1].parent.appendChild(listItem);

            heading.id = `heading${index + 1}`;
        }
    });

    headingListContainer.appendChild(headingList);
});
