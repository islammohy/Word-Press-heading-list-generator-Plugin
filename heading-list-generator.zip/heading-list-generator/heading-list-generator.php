<?php
/**
 * Plugin Name: igy-apps Heading List Generator
 * Description: Automatically generates a hierarchical list for headings and displays it under the [heading_list] shortcode.
 * Version: 1.0
 * Author: igy-apps.com
 * Author URI: igy-apps.com
 */

// Enqueue the JavaScript file and pass the site title and post/page title to it
function heading_list_generator_enqueue_script() {
    wp_enqueue_script(
        'heading-list-generator-script',
        plugin_dir_url(__FILE__) . 'js/heading-list-generators.js',
        array('jquery'),
        '1.0',
        true
    );

    // Pass the site title and post/page title to the JavaScript
    $site_title = wp_strip_all_tags(get_bloginfo('name'));
    $post_title = wp_strip_all_tags(get_the_title());
    wp_localize_script('heading-list-generator-script', 'headingsData', array('siteTitle' => $site_title, 'postTitle' => $post_title));
}

add_action('wp_enqueue_scripts', 'heading_list_generator_enqueue_script');

// Inject the generated list using the [heading_list] shortcode
function heading_list_shortcode() {
    $headingListDiv = '<div id="gheadinglistid"></div>';
    return $headingListDiv;
}

add_shortcode('heading_list', 'heading_list_shortcode');
